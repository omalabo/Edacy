import java.util.*;
/*
 *  Cours de javat ajouter par le developpeur
 */

public class JavaCourse extends Course{
	
	public JavaCourse(int LesTalents) {
        super(LesTalents);
    }

    public String getName() {
    	String om = "Java";
    	return om;
    }

}
