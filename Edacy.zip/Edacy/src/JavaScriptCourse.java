public class JavaScriptCourse extends Course{
	
	/*
	 * Cours de javaScript ajouter par le developpeur
	 */
	public JavaScriptCourse(int LesTalents) {
        super(LesTalents);
    }

    public String getName() {
    	String om = "Java";
    	return om;
    }

}
