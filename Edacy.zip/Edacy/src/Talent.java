import java.util.Arrays;

/*
 * Un constructeur de la class Talent
 * les identifiants d'un talent (son nom age etc....)
 * les methodes getName(), getFirstName(), getAge(), getLevel(), getSpecializationCourse() which return the name, first name, the old, level and specialization course.
 * 
 */

public class Talent {

	
	private School school;
    private Course[] courses;
    
    void setSchool(School school) {
        this.school = school;
    }

    public School getSchool() {
        return school;
    }
    
    
    
    private String name;


    public String getName() {
        return name;
    }
    
    private String FirstName;


    public String getFirstName() {
        return FirstName;
    }
    
    
    private int Age;


    public int getAge() {
        return Age;
    }
    
    protected Talent(String name,String FirstName,int Age) {
        this.name = name;
        this.FirstName = FirstName;
        this.Age = Age;
        courses = new Course[2];
        
    }

    
    
    
	 
	
	
	 void assignCourse(Course course) {
	        for(int i = 0; i < courses.length; i++) {
	            if(course == courses[i])
	                continue;

	            if(courses[i] == null) {
	                course.addTalent(this);
	                courses[i] = course;
	                return;
	            }
	        }
	    }
	
	
	
	    public Course[] getCourses() {
	        return Arrays.copyOf(courses, courses.length);
	    }

	    
	    public boolean isTakingCourse(Course course) {
	        boolean contains = false;
	        for(Course c : courses)
	            return contains = (c == course);

	        return contains;
	    }

}
