/*
 * A constrtuctor method that allows to initialize TalentForeign and this constructor will call the first
 * Ainsi TalentForeign herite de Talent
 */
public class TalentForeign extends Talent{
	
	 private String Nationalite;


	    public String getnationalite() {
	        return Nationalite;
	    }
	public TalentForeign(String name,String FirstName,int Age,int Level,String Nationalite) {
        super( name, FirstName, Age,Level);
        this.Nationalite = Nationalite;
    }
	

}
