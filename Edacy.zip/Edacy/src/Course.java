import java.util.Arrays;
import java.util.UUID;

public abstract  class Course {
    private Talent[] talents;
    private UUID id;

    protected Course(int maxTalents) { //might allow multiple teachers later
        talents = new Talent[maxTalents];

        id = UUID.randomUUID();
    }

    void addTalent(Talent talent) {
        for(int i = 0; i < talents.length; i++) {
            if(talent == talents[i])
                continue;

            if(talents[i] == null) {
            	talents[i] = talent;
                return;
            }
        }
    }   

    public Talent[] getTalents() {
        return Arrays.copyOf(talents, talents.length);
    }

    public boolean isFull() {
        boolean full = true;

        for(Talent talent : talents)
            full = talent != null;

        return full;
    }

    public abstract String getName();
    
}
