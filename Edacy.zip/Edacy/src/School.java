import java.util.Arrays;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;



/*
 * creation de la class School
 * numTalents = nombre effectif de talents
 * menu de choix (0: sortir; 1: ajout talent JAVA; 2: ajout talent JavaScript
 * Controlle de saisi(gestion des exceptions)
 * fonction addTalent() pour ajouter un talent par cours
 * Enregistrement des talents dans un fichier de sauvegarde 
 * affichage de tous les talents d'un cours donnes
 * la methode print() pour afficher l'identite d'un Talent
 */

public class School {
	
	 
	
	 public Talent[] getTalents() {
	        return Arrays.copyOf(talents, talents.length);
	    }

	    public Course[] getCourses() {
	        return Arrays.copyOf(courses, courses.length);
	    }


	 private Course[] courses;
	    private Talent[] talents;
	    
	    
	    
	    
	    public School(Course[] courses) {
	        
	    	this.courses = courses;
	    	
	       
	        int Lestalents = 0;
	        for(Course course : courses)
	        	Lestalents += course.getTalents().length;

	        talents = new Talent[Lestalents];
	    }
	    
	    
	    
	    
	    
	    private void verifyTalent(Talent talent) {
	        verifyCourses(talent);
	        //more will be added here later
	    }

	    private void verifyCourses(Talent talent) {
	        boolean verified = false;

	        //assigns a random course. is there a cleaner way to handle this?
	        while(!verified) { 
	            for(Course course : talent.getCourses()) {
	                if(course == null) {
	                    int index = (int) (Math.random() * courses.length);
	                    talent.assignCourse(courses[index]);
	                }
	            }

	            verified = !Arrays.asList(talent.getCourses()).contains(null);
	        }
	    }
	    
	    
	    
	    
	    public boolean isFull() {
	        boolean full = true;
	        for(Talent Talent : talents)
	            if(Talent == null)
	                return full = false;

	        return full;
	    }
	    
	    
	    public void addTalent(Talent...talents) { 
	    	//this method is pretty messy, and loops quite a few times. any suggestions?
	        if(isFull())
	            throw new IllegalStateException("Cannot register anymore talents at this time");

	        for(Talent talent : talents) {
	            if(Arrays.asList(this.talents).contains(talent)) 
	            	//wrapping the array every loop. is there any better way to do this, without creating my own private contains method for talents?
	                throw new IllegalArgumentException("You cannot add the same Talent to a school twice"); //should I be throwing a runtime exception here? or should i just continue with the rest of the talents

	          //make sure the Talent is ready for school
	            verifyTalent(talent); 
	            talent.setSchool(this);
	            for(int i = 0; i < this.talents.length; i++) {
	                if(this.talents[i] == null) {
	                    this.talents[i] = talent;
	                    break;
	                }
	            }
	        }
	    }
	    
	    
	    
	    
	    public static void main(String[] args) {
	        
	         
            Scanner sc=new Scanner(System.in); 
            int numTalent=0;
	    	
	    	System.out.println("Taper 1 pour ajouter un etudiant au cours de java");
	    	
	    	System.out.println("Taper 2 pour ajouter un etudiant au cours de javaScript");
	    	System.out.println("Taper 0 pour quitter le mode console");
	    	int saisieMenu = sc.nextInt();
	    	   if (saisieMenu == 0)
	            {
	    		   System.exit(0);
	            }
	    	   
	    	   else
	                if (saisieMenu == 1)

	            {
	                	String SaisieEtudiant;
	                	int SaisieEtudiantAge;
	                	String Name;
	                	String FirstName;
	                	int Age;
	                	int Level;
	                	String Nationnalite;
	                	
	                	final String chemin = "logJava.txt";
            	        final File fichier =new File(chemin); 
	                	
	                	System.out.println("Combien d'etudiant voulez vous ajouter");
	                	int nbreEtudiant = sc.nextInt();
	                	Course[] courses = {
	            	            new JavaCourse(nbreEtudiant),
	            	        };
	            	        School school = new School(courses);
	                	for(int i =1;i<=nbreEtudiant;i++)
	                	{
	                		System.out.println("Etudiant 0"+i);
	                		System.out.println("Son nom: ");
	                		SaisieEtudiant = sc.next();
	                		Name = SaisieEtudiant;
	                		
	                		System.out.println("Son Prenom: ");
	                		SaisieEtudiant = sc.next();
	                		FirstName = SaisieEtudiant;
	                		
	                		System.out.println("Son Age: ");
	                		
	                		try {
	                			SaisieEtudiantAge = sc.nextInt();
		                		Age = SaisieEtudiantAge;
	                		
		                		System.out.println("Son Niveau: ");
		                		SaisieEtudiantAge = sc.nextInt();
		                		Level = SaisieEtudiantAge;
	                		
	                		System.out.println("Sa nationnalite: ");
	                		SaisieEtudiant = sc.next();
	                		Nationnalite = SaisieEtudiant;
	                		
	                		TalentForeign ludwig = new TalentForeign(Name,FirstName,Age,Level,Nationnalite);  
	            	        school.addTalent(ludwig);
	            	        cours(school);
	            	        
	            	        numTalent =numTalent+1;
	            	        try {
	            	            // Creation du fichier
	            	            fichier .createNewFile();
	            	            // creation d'un writer 
	            	            final FileWriter writer = new FileWriter(fichier,true);
	            	            try {
	            	                writer.write(numTalent+"            "+Name+"            "+FirstName+"           "+Age+"          "+Level+"           "+Nationnalite+"\n");
	            	            } finally {
	            	                // quoiqu'il arrive, on ferme le fichier
	            	                writer.close();
	            	            }
	            	        } catch (Exception e) {
	            	            System.out.println("Impossible de creer le fichier");
	            	        }
	            	        
	                		}
	                		catch(Exception e)
	                		{
	                			System.out.println("l'age doit etre un entier");
	                		}
	            	        
	            	        
	            	        
	                		
	                		
	                	}
	                	
	                	try{
	         	    		   InputStream flux=new FileInputStream("logJava.txt"); 
	         	    		   InputStreamReader lecture=new InputStreamReader(flux);
	         	    		   BufferedReader buff=new BufferedReader(lecture);
	         	    		   String ligne;
	         	    		  System.out.println("Ainsi tous les etudiants en java sont:");
	         	    		 System.out.println("NUM          NAME          FIRSTNAME          AGE          LEVEL          NATIONNALITE");
	         	    		   while ((ligne=buff.readLine())!=null){
	         	    		   	System.out.println(ligne);
	         	    		   }
	         	    		   buff.close(); 
	         	    		   }		
	         	    		   catch (Exception e){
	         	    		   System.out.println(e.toString());
	         	    		   }
	                	
	                	
	                	
	                	
	            }
	    	   
	    	   
	                else
	                	
	                	if (saisieMenu == 2)

	    	            {
	    	                	String SaisieEtudiant;
	    	                	int SaisieEtudiantAge;
	    	                	String Name;
	    	                	String FirstName;
	    	                	int Age;
	    	                	int Level;
	    	                	String Nationnalite;
	    	                	final String chemin = "logJavaScript.txt";
	                	        final File fichier =new File(chemin); 
	    	                	
	    	                	System.out.println("Combien d'etudiant voulez vous ajouter");
	    	                	int nbreEtudiant = sc.nextInt();
	    	                	Course[] courses = {
	    	            	            new JavaScriptCourse(nbreEtudiant),
	    	            	        };
	    	            	        School school = new School(courses);
	    	                	for(int i =1;i<=nbreEtudiant;i++)
	    	                	{
	    	                		System.out.println("Etudiant "+i+"\n");
	    	                		System.out.println("Son nom: ");
	    	                		SaisieEtudiant = sc.next();
	    	                		Name = SaisieEtudiant;
	    	                		
	    	                		System.out.println("Son Prenom: ");
	    	                		SaisieEtudiant = sc.next();
	    	                		FirstName = SaisieEtudiant;
	    	                		
	    	                		System.out.println("Son Age: ");
	    	                		
	    	                		try {
	    	                			SaisieEtudiantAge = sc.nextInt();
	    		                		Age = SaisieEtudiantAge;
	    	                		
	    		                		System.out.println("Son Niveau: ");
	    		                		SaisieEtudiantAge = sc.nextInt();
	    		                		Level = SaisieEtudiantAge;
	    	                		
	    	                		System.out.println("Sa nationnalite: ");
	    	                		SaisieEtudiant = sc.next();
	    	                		Nationnalite = SaisieEtudiant;
	    	                		
	    	                		TalentForeign ludwig = new TalentForeign(Name,FirstName,Age,Level,Nationnalite);  
	    	            	        school.addTalent(ludwig);
	    	            	        cours(school);
	    	            	        
	    	            	        numTalent =numTalent+1;
	    	            	        try {
	    	            	            // Creation du fichier
	    	            	            fichier .createNewFile();
	    	            	            // creation d'un writer (un �crivain)
	    	            	            final FileWriter writer = new FileWriter(fichier,true);
	    	            	            try {
	    	            	                writer.write(numTalent+"            "+Name+"            "+FirstName+"           "+Age+"          "+Level+"            "+Nationnalite+"\n");
	    	            	            } finally {
	    	            	                // quoiqu'il arrive, on ferme le fichier
	    	            	                writer.close();
	    	            	            }
	    	            	        } catch (Exception e) {
	    	            	            System.out.println("Impossible de creer le fichier de sauvegarde");
	    	            	        }
	    	            	        
	    	                		}
	    	                		catch(Exception e)
	    	                		{
	    	                			System.out.println("Attention l'age doit etre un entier, Anisi pas d'ajout");
	    	                		}
	    	            	        
	    	            	        
	    	            	        
	    	                		
	    	                		
	    	                	}
	    	                	
	    	                	try{
	    	         	    		   InputStream flux=new FileInputStream("logJavaScript.txt"); 
	    	         	    		   InputStreamReader lecture=new InputStreamReader(flux);
	    	         	    		   BufferedReader buff=new BufferedReader(lecture);
	    	         	    		   String ligne;
	    	         	    		  System.out.println("Ainsi tous les etudiants en javaScript sont:");
	    	         	    		 System.out.println("NUM          NAME          FIRSTNAME          AGE          LEVEL          NATIONNALITE");
	    	         	    		   while ((ligne=buff.readLine())!=null){
	    	         	    		   	System.out.println(ligne);
	    	         	    		   }
	    	         	    		   buff.close();
	    	         	    		  System.out.println("Au total "+numTalent+" talents");
	    	         	    		   }		
	    	         	    		   catch (Exception e){
	    	         	    		   System.out.println(e.toString());
	    	         	    		   }
	    	                	
	    	                	
	    	                	
	    	                	
	    	            }
	    	   
	    	   
	                else {
	                	System.out.println("vous devez tapez 0, 1 ou 2");
	                	System.out.println("Redemarez le programme svp");
	                	System.exit(0);
	                }

	    	   

	    	   
	       
	    }
	    
	    
	    
	    
	    
	    

	    static void cours(School school) {
	       
	    		        System.out.println("Vous venez d'ajouter: ");
	        for(Talent talent : school.getTalents()) {
	            if(talent != null) {
	                String message = talent.getName() +" "+ talent.getFirstName() +" "+ talent.getAge() ; 

	                System.out.println(message);
	            }
	        }
	    }
	    
	
}
